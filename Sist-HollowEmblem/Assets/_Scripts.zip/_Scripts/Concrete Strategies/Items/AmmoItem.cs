using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AmmoItem : BaseItem
{
   public override void UseItem()
   {
      base.UseItem();
   }
}
