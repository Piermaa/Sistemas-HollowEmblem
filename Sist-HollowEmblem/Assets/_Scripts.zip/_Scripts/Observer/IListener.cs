using System.Collections;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using UnityEngine;

public interface IListener
{
    void OnEventDispatch();
}
