using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface IPlayerDetector
{
    void OnPlayerDetect();
    void OnPlayerLoose();
}
